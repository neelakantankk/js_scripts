// ==UserScript==
// @name     Append Alfresco to MyCloud Home Page
// @description This Appends an Alfresco logo and link instead of the Google Groups MyCloud
// @version  1
// @grant    none
// @include https://mycloud.pearson.com/
// ==/UserScript==

function create_alfresco_node() {
  var alfresco_icon_container = document.querySelector('.icon-outer-container').cloneNode(true);
  alfresco_icon_container.children[0].href = 'https://uswip.cms.pearson.com';

  alfresco_icon_container.children[0].children[0].setAttribute('data-bind','');
  var alfresco_image_link = 'https://www.sugaroutfitters.com/assets/img/addons/alfresco/logo.png?1487135065';
  alfresco_icon_container.children[0].children[0].setAttribute('src',alfresco_image_link);
  alfresco_icon_container.children[0].children[0].setAttribute('alt','Alfresco');

  alfresco_icon_container.children[0].children[1].innerText = 'Alfresco';
  alfresco_icon_container.children[0].children[1].innerHTML = 'Alfresco';
  
  return alfresco_icon_container;
}

function move_google_group_node() {
  var google_group_node = document.querySelector('a[href*="groups.google.com"]').parentNode;
  var google_group_node_clone = google_group_node.cloneNode(true);
  
  var alfresco_node = create_alfresco_node();
  
  google_group_node.parentNode.replaceChild(alfresco_node,google_group_node);
  
  var last_row = document.querySelector('.icon-outer-container:last-of-type').parentNode;
  last_row.appendChild(google_group_node_clone);
  
}
  
function runOnLoad() {
  console.log('Grease Monkey!');
  if (document.URL!='https://mycloud.pearson.com/') {
    console.log('This is only for the myCloud Applications Page');
  }
  else {
    console.log('Appending Alfresco...');
    move_google_group_node();
  }
}

var load_options = {
  capture:true,
  once:true,
};
document.addEventListener('load',runOnLoad,load_options);