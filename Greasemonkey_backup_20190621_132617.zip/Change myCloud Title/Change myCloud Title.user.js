// ==UserScript==
// @name     Change myCloud Title
// @description Changes the title of the myCloud title page so it looks less weird
// @version  1
// @grant    none
// @include https://mycloud.pearson.com/
// ==/UserScript==

document.title = 'Pearson myCloud Landing Page';
console.log('Grease Monkey!');